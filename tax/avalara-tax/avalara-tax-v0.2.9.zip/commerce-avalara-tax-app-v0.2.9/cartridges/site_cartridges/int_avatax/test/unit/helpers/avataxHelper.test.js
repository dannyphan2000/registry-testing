'use strict';

var assert = require('chai').assert;
var sinon = require('sinon');
var proxyquire = require('proxyquire').noCallThru();

var Money = require('../../mocks/dw/value/Money');
var ProductLineItem = require('../../mocks/dw/order/ProductLineItem');
var ProductShippingLineItem = require('../../mocks/dw/order/ProductShippingLineItem');
var ShippingLineItem = require('../../mocks/dw/order/ShippingLineItem');

describe('avataxHelper', function () {
    var avataxHelper;
    var avataxServiceStub;
    var siteStub;
    var loggerStub;
    var murmurhashStub;
    var taxMgrStub;
    var sessionMock;
    var sitePreferences;

    beforeEach(function () {
        sitePreferences = {};

        loggerStub = {
            warn: sinon.stub(),
            error: sinon.stub(),
            info: sinon.stub()
        };

        avataxServiceStub = {
            call: sinon.stub(),
            CONNECTOR_NAME: 'AvaTax for SFCC',
            CONNECTOR_VERSION: '1.0'
        };

        siteStub = {
            getCurrent: sinon.stub().returns({
                getCustomPreferenceValue: sinon.stub().callsFake(function (key) {
                    return sitePreferences[key] !== undefined ? sitePreferences[key] : null;
                })
            })
        };

        taxMgrStub = {
            TAX_POLICY_GROSS: 1,
            TAX_POLICY_NET: 0,
            taxationPolicy: 0
        };

        murmurhashStub = {
            hashBytes: sinon.stub().returns(99999)
        };

        sessionMock = { custom: {} };
        global.session = sessionMock;

        avataxHelper = proxyquire(
            '../../../cartridge/scripts/helpers/avataxHelper',
            {
                'dw/system/Logger': {
                    getLogger: sinon.stub().returns(loggerStub)
                },
                'dw/system/Site': siteStub,
                'dw/value/Money': Money,
                'dw/order/TaxMgr': taxMgrStub,
                'dw/order/ProductLineItem': ProductLineItem,
                'dw/order/ProductShippingLineItem': ProductShippingLineItem,
                'dw/order/ShippingLineItem': ShippingLineItem,
                '~/cartridge/scripts/services/avataxService': avataxServiceStub,
                '~/cartridge/scripts/helpers/murmurhash': murmurhashStub
            }
        );
    });

    afterEach(function () {
        delete global.session;
        sinon.restore();
    });

    // =========================================================================
    // Helper factories
    // =========================================================================

    function createIterator(items) {
        var index = 0;
        return {
            hasNext: function () { return index < items.length; },
            next: function () { return items[index++]; }
        };
    }

    function createCollection(items) {
        return {
            iterator: function () { return createIterator(items); },
            length: items.length
        };
    }

    function createMockAddress(overrides) {
        return Object.assign({
            address1: '123 Main St',
            address2: '',
            city: 'Seattle',
            stateCode: 'WA',
            countryCode: { value: 'US' },
            postalCode: '98101'
        }, overrides || {});
    }

    function createMockShipment(address, id) {
        return {
            ID: id || 'shipment-1',
            getShippingAddress: sinon.stub().returns(address),
            getShippingLineItems: sinon.stub().returns(createCollection([]))
        };
    }

    function createMockProductLineItem(overrides) {
        var defaults = {
            UUID: 'pli-uuid-1',
            productID: 'PROD-001',
            productName: 'Test Product',
            quantityValue: 2,
            proratedPrice: { value: 29.99 },
            taxClassID: 'P0000000',
            optionProductLineItems: createCollection([]),
            shippingLineItem: null,
            getProduct: sinon.stub().returns({
                UPC: '012345678901',
                taxClassID: 'P0000000',
                shortDescription: { source: { toString: function () { return 'A test product'; } } }
            }),
            getShipment: sinon.stub()
        };
        return Object.assign(defaults, overrides || {});
    }

    function createMockBasket(options) {
        options = options || {};
        var productLineItems = options.productLineItems || [];
        var shipments = options.shipments || [];
        var giftCertLineItems = options.giftCertLineItems || [];
        var allLineItems = options.allLineItems || [];

        return {
            getUUID: sinon.stub().returns(options.uuid || 'basket-uuid-1'),
            getCurrencyCode: sinon.stub().returns(options.currency || 'USD'),
            getCustomerEmail: sinon.stub().returns(options.customerEmail || 'test@example.com'),
            getCustomer: sinon.stub().returns(options.customer || null),
            getProductLineItems: sinon.stub().returns(createCollection(productLineItems)),
            getShipments: sinon.stub().returns(createCollection(shipments)),
            getGiftCertificateLineItems: sinon.stub().returns(createCollection(giftCertLineItems)),
            getBillingAddress: sinon.stub().returns(options.billingAddress || null),
            getAllLineItems: sinon.stub().returns(createCollection(allLineItems)),
            updateTotals: sinon.stub(),
            priceAdjustments: createCollection(options.priceAdjustments || []),
            shippingPriceAdjustments: createCollection(options.shippingPriceAdjustments || []),
            custom: {}
        };
    }

    function createMockCustomer(overrides) {
        var profileDefaults = {
            customerNo: 'CUST-001',
            email: 'profile@example.com',
            taxID: 'TAX-123',
            custom: { ATisSellerImporterOfRecord: false }
        };
        return {
            profile: Object.assign(profileDefaults, overrides || {})
        };
    }

    // =========================================================================
    // getCustomerCode (tested via buildTransactionModel)
    // =========================================================================
    describe('getCustomerCode (via buildTransactionModel)', function () {
        var defaultShipment;
        var defaultPli;

        beforeEach(function () {
            sitePreferences.ATEnable = true;
            sitePreferences.AtCompanyCode = 'CO';
            var address = createMockAddress();
            defaultShipment = createMockShipment(address);
            defaultPli = createMockProductLineItem();
            defaultPli.getShipment.returns(defaultShipment);
        });

        it('should use customerNo when preference is customer_number', function () {
            sitePreferences.ATCustomerCode = 'customer_number';
            var customer = createMockCustomer({ customerNo: 'CN-999' });
            var basket = createMockBasket({
                customer: customer,
                productLineItems: [defaultPli],
                shipments: [defaultShipment]
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.equal(result.model.customerCode, 'CN-999');
        });

        it('should use basket email when preference is customer_email', function () {
            sitePreferences.ATCustomerCode = 'customer_email';
            var customer = createMockCustomer();
            var basket = createMockBasket({
                customer: customer,
                customerEmail: 'basket@test.com',
                productLineItems: [defaultPli],
                shipments: [defaultShipment]
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.equal(result.model.customerCode, 'basket@test.com');
        });

        it('should fall back to profile email when basket email is null', function () {
            sitePreferences.ATCustomerCode = 'customer_email';
            var customer = createMockCustomer({ email: 'fallback@test.com' });
            var basket = createMockBasket({
                customer: customer,
                productLineItems: [defaultPli],
                shipments: [defaultShipment]
            });
            basket.getCustomerEmail.returns(null);

            var result = avataxHelper.buildTransactionModel(basket);

            assert.equal(result.model.customerCode, 'fallback@test.com');
        });

        it('should use custom attribute when preference is custom_attribute', function () {
            sitePreferences.ATCustomerCode = 'custom_attribute';
            sitePreferences.ATCustomCustomerCode = { toString: function () { return 'loyaltyId'; }, trim: function () { return 'loyaltyId'; } };
            var customer = createMockCustomer({ loyaltyId: 'LOYAL-42' });
            var basket = createMockBasket({
                customer: customer,
                productLineItems: [defaultPli],
                shipments: [defaultShipment]
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.equal(result.model.customerCode, 'LOYAL-42');
        });

        it('should fall back to customerNo when custom attribute is not found', function () {
            sitePreferences.ATCustomerCode = 'custom_attribute';
            sitePreferences.ATCustomCustomerCode = { toString: function () { return 'nonExistentAttr'; }, trim: function () { return 'nonExistentAttr'; } };
            var customer = createMockCustomer({ customerNo: 'CN-FALLBACK' });
            var basket = createMockBasket({
                customer: customer,
                productLineItems: [defaultPli],
                shipments: [defaultShipment]
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.equal(result.model.customerCode, 'CN-FALLBACK');
        });

        it('should fall back to customerNo for unknown preference value', function () {
            sitePreferences.ATCustomerCode = 'some_unknown_strategy';
            var customer = createMockCustomer({ customerNo: 'CN-DEFAULT' });
            var basket = createMockBasket({
                customer: customer,
                productLineItems: [defaultPli],
                shipments: [defaultShipment]
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.equal(result.model.customerCode, 'CN-DEFAULT');
        });

        it('should return basket email for guest customer', function () {
            sitePreferences.ATCustomerCode = 'customer_email';
            var basket = createMockBasket({
                customer: { profile: null },
                customerEmail: 'guest@shop.com',
                productLineItems: [defaultPli],
                shipments: [defaultShipment]
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.equal(result.model.customerCode, 'guest@shop.com');
        });
    });

    // =========================================================================
    // buildTransactionModel
    // =========================================================================
    describe('buildTransactionModel', function () {
        var address;
        var shipment;

        beforeEach(function () {
            sitePreferences.ATEnable = true;
            sitePreferences.AtCompanyCode = 'TESTCO';
            sitePreferences.AtShipFromLine1 = '100 Warehouse Ave';
            sitePreferences.AtShipFromCity = 'Portland';
            sitePreferences.AtShipFromStateCode = 'OR';
            sitePreferences.AtShipFromCountryCode = 'US';
            sitePreferences.AtShipFromZipCode = '97201';

            address = createMockAddress();
            shipment = createMockShipment(address, 'ship-1');
        });

        it('should build correct top-level transaction model structure', function () {
            var pli = createMockProductLineItem();
            pli.getShipment.returns(shipment);
            var customer = createMockCustomer();
            var basket = createMockBasket({
                customer: customer,
                uuid: 'basket-123',
                currency: 'USD',
                productLineItems: [pli],
                shipments: [shipment]
            });

            var result = avataxHelper.buildTransactionModel(basket);
            var model = result.model;

            assert.equal(model.code, 'basket-123');
            assert.equal(model.type, 'SalesOrder');
            assert.equal(model.companyCode, 'TESTCO');
            assert.equal(model.currencyCode, 'USD');
            assert.equal(model.businessIdentificationNo, 'TAX-123');
            assert.isFalse(model.isSellerImporterOfRecord);
            assert.isFalse(model.commit);
            assert.equal(model.debugLevel, 'Normal');
            assert.isArray(model.lines);
        });

        it('should process product line items with correct fields', function () {
            var pli = createMockProductLineItem({
                UUID: 'pli-1',
                productID: 'SKU-100',
                quantityValue: 3,
                proratedPrice: { value: 59.97 }
            });
            pli.getProduct.returns({
                UPC: '111222333444',
                taxClassID: 'CUSTOM_TAX',
                shortDescription: { source: { toString: function () { return 'Widget'; } } }
            });
            pli.getShipment.returns(shipment);
            var basket = createMockBasket({
                customer: createMockCustomer(),
                productLineItems: [pli],
                shipments: [shipment]
            });

            var result = avataxHelper.buildTransactionModel(basket);
            var line = result.model.lines[0];

            assert.equal(line.number, 1);
            assert.equal(line.quantity, 3);
            assert.equal(line.amount, 59.97);
            assert.equal(line.taxCode, 'CUSTOM_TAX');
            assert.equal(line.itemCode, 'UPC:111222333444');
            assert.equal(line.description, 'Widget');
        });

        it('should use productName as itemCode when UPC is not available', function () {
            var pli = createMockProductLineItem({ productName: 'Fancy Hat' });
            pli.getProduct.returns({
                UPC: null,
                taxClassID: 'P0000000',
                shortDescription: { source: { toString: function () { return ''; } } }
            });
            pli.getShipment.returns(shipment);
            var basket = createMockBasket({
                customer: createMockCustomer(),
                productLineItems: [pli],
                shipments: [shipment]
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.equal(result.model.lines[0].itemCode, 'Fancy Hat');
        });

        it('should set taxIncluded true when tax policy is GROSS', function () {
            taxMgrStub.taxationPolicy = taxMgrStub.TAX_POLICY_GROSS;
            var pli = createMockProductLineItem();
            pli.getShipment.returns(shipment);
            var basket = createMockBasket({
                customer: createMockCustomer(),
                productLineItems: [pli],
                shipments: [shipment]
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.isTrue(result.model.lines[0].taxIncluded);
        });

        it('should skip product line items without shipping address', function () {
            var pli = createMockProductLineItem();
            pli.getShipment.returns({ getShippingAddress: sinon.stub().returns(null), ID: 'no-addr' });
            var basket = createMockBasket({
                customer: createMockCustomer(),
                productLineItems: [pli],
                shipments: []
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.equal(result.model.lines.length, 0);
        });

        it('should skip product line items without shipment', function () {
            var pli = createMockProductLineItem();
            pli.getShipment.returns(null);
            var basket = createMockBasket({
                customer: createMockCustomer(),
                productLineItems: [pli],
                shipments: []
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.equal(result.model.lines.length, 0);
        });

        it('should build correct lineUUIDMap', function () {
            var pli = createMockProductLineItem({ UUID: 'uuid-abc', productID: 'SKU-1' });
            pli.getShipment.returns(shipment);
            var basket = createMockBasket({
                customer: createMockCustomer(),
                productLineItems: [pli],
                shipments: [shipment]
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.deepEqual(result.lineUUIDMap[1], {
                uuid: 'uuid-abc',
                shipmentId: 'ship-1',
                itemId: 'SKU-1'
            });
        });

        it('should include businessIdentificationNo from customer profile', function () {
            var customer = createMockCustomer({ taxID: 'VAT-EU-123' });
            var pli = createMockProductLineItem();
            pli.getShipment.returns(shipment);
            var basket = createMockBasket({
                customer: customer,
                productLineItems: [pli],
                shipments: [shipment]
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.equal(result.model.businessIdentificationNo, 'VAT-EU-123');
            assert.equal(result.model.lines[0].businessIdentificationNo, 'VAT-EU-123');
        });

        it('should set isSellerImporterOfRecord from customer profile', function () {
            var customer = createMockCustomer();
            customer.profile.custom.ATisSellerImporterOfRecord = true;
            var pli = createMockProductLineItem();
            pli.getShipment.returns(shipment);
            var basket = createMockBasket({
                customer: customer,
                productLineItems: [pli],
                shipments: [shipment]
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.isTrue(result.model.isSellerImporterOfRecord);
        });

        // --- Option line items ---
        it('should process option line items nested under product line items', function () {
            var optionItem = {
                UUID: 'oli-uuid-1',
                optionID: 'OPT-1',
                productName: 'Gift Wrapping',
                quantityValue: 1,
                proratedPrice: { value: 4.99 },
                taxClassID: 'P0000000'
            };
            var pli = createMockProductLineItem();
            pli.getShipment.returns(shipment);
            pli.optionProductLineItems = createCollection([optionItem]);
            var basket = createMockBasket({
                customer: createMockCustomer(),
                productLineItems: [pli],
                shipments: [shipment]
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.equal(result.model.lines.length, 2);
            var optionLine = result.model.lines[1];
            assert.equal(optionLine.amount, 4.99);
            assert.equal(optionLine.itemCode, 'Gift Wrapping');
            assert.equal(result.lineUUIDMap[2].uuid, 'oli-uuid-1');
            assert.equal(result.lineUUIDMap[2].itemId, 'OPT-1');
        });

        // --- Product-level shipping line item ---
        it('should process product-level shipping line items', function () {
            var psli = {
                UUID: 'psli-uuid-1',
                ID: 'PSLI-1',
                lineItemText: 'Oversized Surcharge',
                adjustedPrice: { value: 12.50 },
                taxClassID: 'FR020100'
            };
            var pli = createMockProductLineItem();
            pli.getShipment.returns(shipment);
            pli.shippingLineItem = psli;
            var basket = createMockBasket({
                customer: createMockCustomer(),
                productLineItems: [pli],
                shipments: [shipment]
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.equal(result.model.lines.length, 2);
            var shippingLine = result.model.lines[1];
            assert.equal(shippingLine.amount, 12.50);
            assert.equal(shippingLine.quantity, 1);
            assert.equal(shippingLine.itemCode, 'Oversized Surcharge');
        });

        // --- Shipment-level shipping line items ---
        it('should process shipment-level shipping line items', function () {
            var sli = {
                UUID: 'sli-uuid-1',
                ID: 'StandardShipping',
                lineItemText: 'Standard Ground',
                adjustedPrice: { value: 7.99 },
                taxClassID: 'FR020100'
            };
            shipment.getShippingLineItems.returns(createCollection([sli]));
            var basket = createMockBasket({
                customer: createMockCustomer(),
                productLineItems: [],
                shipments: [shipment]
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.equal(result.model.lines.length, 1);
            assert.equal(result.model.lines[0].amount, 7.99);
            assert.equal(result.model.lines[0].itemCode, 'StandardShipping');
        });

        it('should skip shipping line items with zero amount', function () {
            var sli = {
                UUID: 'sli-free',
                ID: 'FreeShipping',
                adjustedPrice: { value: 0 },
                taxClassID: 'FR020100'
            };
            shipment.getShippingLineItems.returns(createCollection([sli]));
            var basket = createMockBasket({
                customer: createMockCustomer(),
                productLineItems: [],
                shipments: [shipment]
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.equal(result.model.lines.length, 0);
        });


        // --- Gift certificate line items ---
        it('should process gift certificate line items with PG050000 tax code', function () {
            var gcShipment = createMockShipment(createMockAddress(), 'gc-ship');
            var gc = {
                UUID: 'gc-uuid-1',
                giftCertificateID: 'GC-001',
                lineItemText: 'Gift Card $50',
                shipment: gcShipment,
                getPriceValue: sinon.stub().returns(50.00)
            };
            var basket = createMockBasket({
                customer: createMockCustomer(),
                productLineItems: [],
                shipments: [],
                giftCertLineItems: [gc]
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.equal(result.model.lines.length, 1);
            assert.equal(result.model.lines[0].taxCode, 'PG050000');
            assert.equal(result.model.lines[0].amount, 50);
            assert.equal(result.lineUUIDMap[1].itemId, 'GC-001');
        });

        it('should fall back to billing address for gift certs without shipment address', function () {
            var billingAddress = createMockAddress({ city: 'Billing City' });
            var gc = {
                UUID: 'gc-uuid-2',
                giftCertificateID: 'GC-002',
                lineItemText: 'Gift Card',
                shipment: { getShippingAddress: sinon.stub().returns(null), ID: 'gc-s' },
                getPriceValue: sinon.stub().returns(25)
            };
            var basket = createMockBasket({
                customer: createMockCustomer(),
                productLineItems: [],
                shipments: [],
                giftCertLineItems: [gc],
                billingAddress: billingAddress
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.equal(result.model.lines[0].addresses.shipTo.city, 'Billing City');
        });

        it('should skip gift certs with no address available', function () {
            var gc = {
                UUID: 'gc-uuid-3',
                giftCertificateID: 'GC-003',
                lineItemText: 'Gift Card',
                shipment: { getShippingAddress: sinon.stub().returns(null), ID: 'gc-s' },
                getPriceValue: sinon.stub().returns(25)
            };
            var basket = createMockBasket({
                customer: createMockCustomer(),
                productLineItems: [],
                shipments: [],
                giftCertLineItems: [gc],
                billingAddress: null
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.equal(result.model.lines.length, 0);
        });

        it('should log warning when no taxable line items found', function () {
            var basket = createMockBasket({
                customer: createMockCustomer(),
                productLineItems: [],
                shipments: [],
                giftCertLineItems: [],
                uuid: 'empty-basket'
            });

            avataxHelper.buildTransactionModel(basket);

            assert.isTrue(loggerStub.warn.calledOnce);
            assert.include(loggerStub.warn.firstCall.args[0], 'empty-basket');
        });
    });

    // =========================================================================
    // callAvaTaxAPI
    // =========================================================================
    describe('callAvaTaxAPI', function () {
        var transactionModel;

        beforeEach(function () {
            transactionModel = {
                code: 'basket-1',
                lines: [{ number: 1 }]
            };
        });

        it('should call avataxService with POST to /api/v2/transactions/create', function () {
            avataxServiceStub.call.returns({ success: true, data: { id: 1 }, latency: 50 });

            avataxHelper.callAvaTaxAPI(transactionModel);

            assert.isTrue(avataxServiceStub.call.calledOnce);
            assert.equal(avataxServiceStub.call.firstCall.args[0], 'POST');
            assert.equal(avataxServiceStub.call.firstCall.args[1], '/api/v2/transactions/create');
            assert.deepEqual(avataxServiceStub.call.firstCall.args[2], transactionModel);
        });

        it('should return success response and store hash in session', function () {
            avataxServiceStub.call.returns({ success: true, data: { id: 1 }, latency: 50 });

            var result = avataxHelper.callAvaTaxAPI(transactionModel);

            assert.isTrue(result.success);
            assert.equal(sessionMock.custom.avataxtransactionmodel, 99999);
        });

        it('should return deduplicated response when hash matches session', function () {
            murmurhashStub.hashBytes.returns(55555);
            sessionMock.custom.avataxtransactionmodel = 55555;

            var result = avataxHelper.callAvaTaxAPI(transactionModel);

            assert.isTrue(result.success);
            assert.isTrue(result.deduplicated);
            assert.isTrue(avataxServiceStub.call.notCalled);
        });

        it('should NOT deduplicate when hash differs from session', function () {
            murmurhashStub.hashBytes.returns(11111);
            sessionMock.custom.avataxtransactionmodel = 22222;
            avataxServiceStub.call.returns({ success: true, data: {}, latency: 10 });

            var result = avataxHelper.callAvaTaxAPI(transactionModel);

            assert.isFalse(!!result.deduplicated);
            assert.isTrue(avataxServiceStub.call.calledOnce);
        });

        it('should return error response on API failure', function () {
            avataxServiceStub.call.returns({ success: false, error: 'Bad request', latency: 30 });

            var result = avataxHelper.callAvaTaxAPI(transactionModel);

            assert.isFalse(result.success);
            assert.equal(result.error, 'Bad request');
        });

});

    // =========================================================================
    // commitTransaction
    // =========================================================================
    describe('commitTransaction', function () {
        it('should call correct API endpoint with company code and transaction code', function () {
            sitePreferences.AtDocumentCommitAllowed = true;
            sitePreferences.AtCompanyCode = 'MYCO';
            avataxServiceStub.call.returns({ success: true, data: {}, latency: 50 });

            avataxHelper.commitTransaction('ORD-100');

            var endpoint = avataxServiceStub.call.firstCall.args[1];
            assert.include(endpoint, '/api/v2/companies/MYCO/transactions/ORD-100/commit');
            assert.deepEqual(avataxServiceStub.call.firstCall.args[2], { commit: true });
        });

        it('should URL-encode company code and transaction code', function () {
            sitePreferences.AtDocumentCommitAllowed = true;
            sitePreferences.AtCompanyCode = 'MY CO/INC';
            avataxServiceStub.call.returns({ success: true, data: {}, latency: 10 });

            avataxHelper.commitTransaction('ORD 200/A');

            var endpoint = avataxServiceStub.call.firstCall.args[1];
            assert.include(endpoint, encodeURIComponent('MY CO/INC'));
            assert.include(endpoint, encodeURIComponent('ORD 200/A'));
        });

        it('should return error when saveTransactions is disabled', function () {
            sitePreferences.AtDocumentCommitAllowed = false;

            var result = avataxHelper.commitTransaction('ORD-1');

            assert.isFalse(result.success);
            assert.include(result.error, 'AtDocumentCommitAllowed');
            assert.isTrue(avataxServiceStub.call.notCalled);
        });

        it('should return error when companyCode is not configured', function () {
            sitePreferences.AtDocumentCommitAllowed = true;
            sitePreferences.AtCompanyCode = '';

            var result = avataxHelper.commitTransaction('ORD-1');

            assert.isFalse(result.success);
            assert.include(result.error, 'AtCompanyCode');
            assert.isTrue(avataxServiceStub.call.notCalled);
        });

});

    // =========================================================================
    // voidTransaction
    // =========================================================================
    describe('voidTransaction', function () {
        it('should call correct API endpoint with /void suffix', function () {
            sitePreferences.AtDocumentCommitAllowed = true;
            sitePreferences.AtCompanyCode = 'VOIDCO';
            avataxServiceStub.call.returns({ success: true, data: {}, latency: 30 });

            avataxHelper.voidTransaction('ORD-V1');

            var endpoint = avataxServiceStub.call.firstCall.args[1];
            assert.include(endpoint, '/api/v2/companies/VOIDCO/transactions/ORD-V1/void');
            assert.deepEqual(avataxServiceStub.call.firstCall.args[2], { code: 'DocVoided' });
        });

        it('should return error when saveTransactions is disabled', function () {
            sitePreferences.AtDocumentCommitAllowed = false;

            var result = avataxHelper.voidTransaction('ORD-V3');

            assert.isFalse(result.success);
            assert.include(result.error, 'AtDocumentCommitAllowed');
            assert.isTrue(avataxServiceStub.call.notCalled);
        });

        it('should return error when companyCode is not configured', function () {
            sitePreferences.AtDocumentCommitAllowed = true;
            sitePreferences.AtCompanyCode = '';

            var result = avataxHelper.voidTransaction('ORD-V4');

            assert.isFalse(result.success);
            assert.include(result.error, 'AtCompanyCode');
        });

});

    // =========================================================================
    // applyTaxesToBasket
    // =========================================================================
    describe('applyTaxesToBasket', function () {
        function createProductLineItemInstance(props) {
            var item = new ProductLineItem();
            Object.assign(item, {
                UUID: props.uuid || 'pli-1',
                setTaxRate: sinon.stub(),
                updateTax: sinon.stub(),
                priceAdjustments: createCollection(props.priceAdjustments || [])
            });
            // Allow direct property set for tax
            Object.defineProperty(item, 'tax', { writable: true, value: null });
            return item;
        }

        function createShippingLineItemInstance(props) {
            var item = new ShippingLineItem();
            Object.assign(item, {
                UUID: props.uuid || 'sli-1',
                setTaxRate: sinon.stub(),
                updateTax: sinon.stub(),
                shippingPriceAdjustments: createCollection(props.shippingPriceAdjustments || [])
            });
            Object.defineProperty(item, 'tax', { writable: true, value: null });
            return item;
        }

        it('should set tax rate and tax amount on matched line items', function () {
            var lineItem = createProductLineItemInstance({ uuid: 'uuid-1' });
            var basket = createMockBasket({
                currency: 'USD',
                allLineItems: [lineItem]
            });
            var avaTaxResponse = {
                lines: [{
                    lineNumber: 1,
                    tax: 2.50,
                    taxableAmount: 25.00
                }]
            };
            var lineUUIDMap = { 1: { uuid: 'uuid-1', shipmentId: 's1', itemId: 'P1' } };

            avataxHelper.applyTaxesToBasket(basket, avaTaxResponse, lineUUIDMap);

            assert.isTrue(lineItem.setTaxRate.calledWith(0.1));
            assert.isTrue(lineItem.updateTax.calledWith(0.1));
            assert.equal(lineItem.tax.value, 2.50);
            assert.equal(lineItem.tax.currencyCode, 'USD');
        });

        it('should handle missing UUID mapping gracefully', function () {
            var basket = createMockBasket({ allLineItems: [] });
            var avaTaxResponse = {
                lines: [{ lineNumber: 99, tax: 1.00, taxableAmount: 10.00 }]
            };
            var lineUUIDMap = {};

            avataxHelper.applyTaxesToBasket(basket, avaTaxResponse, lineUUIDMap);

            assert.isTrue(loggerStub.warn.called);
            assert.include(loggerStub.warn.firstCall.args[0], '99');
        });

        it('should handle line item not found for UUID gracefully', function () {
            var basket = createMockBasket({ allLineItems: [] });
            var avaTaxResponse = {
                lines: [{ lineNumber: 1, tax: 1, taxableAmount: 10 }]
            };
            var lineUUIDMap = { 1: { uuid: 'missing-uuid', shipmentId: 's1', itemId: 'P1' } };

            avataxHelper.applyTaxesToBasket(basket, avaTaxResponse, lineUUIDMap);

            assert.isTrue(loggerStub.warn.called);
            assert.include(loggerStub.warn.lastCall.args[0], 'missing-uuid');
        });

        it('should zero out price adjustments on ProductLineItem', function () {
            var pa = { updateTax: sinon.stub() };
            var lineItem = createProductLineItemInstance({ uuid: 'uuid-pa', priceAdjustments: [pa] });
            var basket = createMockBasket({ allLineItems: [lineItem] });
            var avaTaxResponse = {
                lines: [{ lineNumber: 1, tax: 1, taxableAmount: 10 }]
            };
            var lineUUIDMap = { 1: { uuid: 'uuid-pa', shipmentId: 's', itemId: 'P' } };

            avataxHelper.applyTaxesToBasket(basket, avaTaxResponse, lineUUIDMap);

            assert.isTrue(pa.updateTax.calledWith(0));
        });

        it('should zero out shipping price adjustments on ShippingLineItem', function () {
            var spa = { updateTax: sinon.stub() };
            var lineItem = createShippingLineItemInstance({ uuid: 'uuid-spa', shippingPriceAdjustments: [spa] });
            var basket = createMockBasket({ allLineItems: [lineItem] });
            var avaTaxResponse = {
                lines: [{ lineNumber: 1, tax: 0.50, taxableAmount: 5 }]
            };
            var lineUUIDMap = { 1: { uuid: 'uuid-spa', shipmentId: 's', itemId: 'S' } };

            avataxHelper.applyTaxesToBasket(basket, avaTaxResponse, lineUUIDMap);

            assert.isTrue(spa.updateTax.calledWith(0));
        });

        it('should zero out basket-level price adjustments', function () {
            var basketPA = { updateTax: sinon.stub() };
            var basketSPA = { updateTax: sinon.stub() };
            var basket = createMockBasket({
                allLineItems: [],
                priceAdjustments: [basketPA],
                shippingPriceAdjustments: [basketSPA]
            });
            var avaTaxResponse = { lines: [] };

            avataxHelper.applyTaxesToBasket(basket, avaTaxResponse, {});

            assert.isTrue(basketPA.updateTax.calledWith(0));
            assert.isTrue(basketSPA.updateTax.calledWith(0));
        });

        it('should call basket.updateTotals at the end', function () {
            var basket = createMockBasket({ allLineItems: [] });
            var avaTaxResponse = { lines: [] };

            avataxHelper.applyTaxesToBasket(basket, avaTaxResponse, {});

            assert.isTrue(basket.updateTotals.calledOnce);
        });

        it('should handle null response gracefully', function () {
            var basket = createMockBasket({ allLineItems: [] });

            avataxHelper.applyTaxesToBasket(basket, null, {});

            assert.isTrue(loggerStub.warn.called);
        });

        // --- storeTaxDetails (tested indirectly) ---
        it('should store tax jurisdiction details in basket.custom.ATTaxDetail', function () {
            var lineItem = createProductLineItemInstance({ uuid: 'uuid-td' });
            var basket = createMockBasket({ allLineItems: [lineItem] });
            var avaTaxResponse = {
                lines: [{
                    lineNumber: 1,
                    tax: 2.00,
                    taxableAmount: 20.00,
                    details: [
                        {
                            jurisdictionType: 'State',
                            jurisName: 'WASHINGTON',
                            exemptAmount: 0,
                            nonTaxableAmount: 0,
                            taxableAmount: 20,
                            rate: 0.065,
                            tax: 1.30
                        },
                        {
                            jurisdictionType: 'City',
                            jurisName: 'SEATTLE',
                            exemptAmount: 0,
                            nonTaxableAmount: 0,
                            taxableAmount: 20,
                            rate: 0.035,
                            tax: 0.70
                        }
                    ]
                }]
            };
            var lineUUIDMap = { 1: { uuid: 'uuid-td', shipmentId: 's1', itemId: 'ITEM-1' } };

            avataxHelper.applyTaxesToBasket(basket, avaTaxResponse, lineUUIDMap);

            assert.isDefined(basket.custom.ATTaxDetail);
            var parsed = JSON.parse(basket.custom.ATTaxDetail);
            assert.equal(parsed.length, 1);
            assert.equal(parsed[0].lineitemid, 'ITEM-1');
            assert.equal(parsed[0].shipmentid, 's1');
            assert.equal(parsed[0].taxes.length, 2);
            assert.equal(parsed[0].taxes[0].jurisdiction, 'WASHINGTON');
            assert.equal(parsed[0].taxes[1].jurisdiction, 'SEATTLE');
        });

        // --- storeInvoiceMessages (tested indirectly) ---
        it('should store VAT invoice messages in basket.custom.ATInvoiceMessage', function () {
            var basket = createMockBasket({ allLineItems: [] });
            var avaTaxResponse = {
                lines: [],
                messages: [
                    { summary: 'Some other message', details: 'irrelevant' },
                    { summary: 'Invoice  Messages for EU', details: 'VAT: 20% standard rate applies' }
                ]
            };

            avataxHelper.applyTaxesToBasket(basket, avaTaxResponse, {});

            assert.equal(basket.custom.ATInvoiceMessage, 'VAT: 20% standard rate applies');
            assert.equal(sessionMock.custom.ATInvoiceMessage, 'VAT: 20% standard rate applies');
        });

});

    // =========================================================================
    // getLineItemByUUID (tested indirectly via applyTaxesToBasket)
    // =========================================================================
    describe('getLineItemByUUID (via applyTaxesToBasket)', function () {
        it('should find a regular line item by UUID', function () {
            var lineItem = createMockProductLineItemForApply('target-uuid');
            var basket = createMockBasket({ allLineItems: [lineItem] });
            var response = { lines: [{ lineNumber: 1, tax: 1, taxableAmount: 10 }] };
            var map = { 1: { uuid: 'target-uuid', shipmentId: 's', itemId: 'P' } };

            avataxHelper.applyTaxesToBasket(basket, response, map);

            assert.isTrue(lineItem.setTaxRate.called);
        });

        it('should find nested shippingLineItem by UUID', function () {
            var nestedSli = {
                UUID: 'nested-sli-uuid',
                setTaxRate: sinon.stub(),
                updateTax: sinon.stub()
            };
            Object.defineProperty(nestedSli, 'tax', { writable: true, value: null });

            var parentPli = {
                UUID: 'parent-uuid',
                shippingLineItem: nestedSli,
                setTaxRate: sinon.stub(),
                updateTax: sinon.stub()
            };

            var basket = createMockBasket({ allLineItems: [parentPli] });
            var response = { lines: [{ lineNumber: 1, tax: 0.50, taxableAmount: 5 }] };
            var map = { 1: { uuid: 'nested-sli-uuid', shipmentId: 's', itemId: 'SLI' } };

            avataxHelper.applyTaxesToBasket(basket, response, map);

            assert.isTrue(nestedSli.setTaxRate.called);
        });

        it('should return null and log warning when UUID not found', function () {
            var basket = createMockBasket({ allLineItems: [] });
            var response = { lines: [{ lineNumber: 1, tax: 1, taxableAmount: 10 }] };
            var map = { 1: { uuid: 'nonexistent', shipmentId: 's', itemId: 'P' } };

            avataxHelper.applyTaxesToBasket(basket, response, map);

            assert.isTrue(loggerStub.warn.called);
            assert.include(loggerStub.warn.lastCall.args[0], 'nonexistent');
        });

        function createMockProductLineItemForApply(uuid) {
            var item = new ProductLineItem();
            item.UUID = uuid;
            item.setTaxRate = sinon.stub();
            item.updateTax = sinon.stub();
            item.priceAdjustments = createCollection([]);
            Object.defineProperty(item, 'tax', { writable: true, value: null });
            return item;
        }
    });
});
