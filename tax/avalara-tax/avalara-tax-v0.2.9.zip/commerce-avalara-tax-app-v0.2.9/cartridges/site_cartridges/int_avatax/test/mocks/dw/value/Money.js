'use strict';

function Money(amount, currencyCode) {
    this.value = amount;
    this.currencyCode = currencyCode;
    this.available = true;
}

Money.prototype.getValue = function () {
    return this.value;
};

Money.prototype.getCurrencyCode = function () {
    return this.currencyCode;
};

module.exports = Money;
