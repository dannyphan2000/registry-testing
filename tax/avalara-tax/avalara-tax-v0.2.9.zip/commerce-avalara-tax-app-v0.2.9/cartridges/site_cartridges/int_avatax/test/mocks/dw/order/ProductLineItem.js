'use strict';

function ProductLineItem() {}

module.exports = ProductLineItem;
