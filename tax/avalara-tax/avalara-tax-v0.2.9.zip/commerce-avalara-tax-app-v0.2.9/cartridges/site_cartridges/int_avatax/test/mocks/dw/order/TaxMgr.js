'use strict';

module.exports = {
    TAX_POLICY_GROSS: 1,
    TAX_POLICY_NET: 0,
    taxationPolicy: 0
};
