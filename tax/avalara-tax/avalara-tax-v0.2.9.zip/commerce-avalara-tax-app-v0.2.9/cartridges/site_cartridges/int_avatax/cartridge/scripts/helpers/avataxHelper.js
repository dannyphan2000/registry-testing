'use strict';

var Logger = require('dw/system/Logger');
var Site = require('dw/system/Site');
var avataxService = require('~/cartridge/scripts/services/avataxService');

var logger = Logger.getLogger('AvaTax', 'avataxHelper');

var CONNECTOR_NAME = avataxService.CONNECTOR_NAME;
var CONNECTOR_VERSION = avataxService.CONNECTOR_VERSION;

/**
 * Emits a structured log entry matching the Avalara connector logging standard.
 * Uses INFO level for performance/instrumentation, ERROR level for errors/exceptions.
 *
 * @param {Object} params - Log parameters
 * @param {string} params.operation - API operation name (e.g. CreateTransaction, CommitTransaction)
 * @param {string} params.docCode - Document/order code
 * @param {string} [params.logType] - 'Performance' or 'Debug'
 * @param {string} [params.logLevel] - 'Informational', 'Error', or 'Exception'
 * @param {boolean} [params.error] - Whether this is an error entry
 * @param {string} [params.errorType] - Error classification (Exception, Data, Configuration)
 * @param {string} [params.message] - Human-readable message
 * @param {number} [params.lineCount] - Number of line items
 * @param {number} [params.connectorTime] - Time spent in connector code (ms)
 * @param {number} [params.latency] - Time spent waiting for API response (ms)
 */
function logStructured(params) {
    var entry = {
        ConnectorName: CONNECTOR_NAME,
        ConnectorVersion: CONNECTOR_VERSION,
        Operation: params.operation,
        DocCode: params.docCode || '',
        DocType: 'SalesOrder',
        LogType: params.logType || 'Debug',
        LogLevel: params.logLevel || 'Informational',
        Error: params.error || false,
        Message: params.message || ''
    };

    if (params.errorType) {
        entry.ErrorType = params.errorType;
    }
    if (params.lineCount !== undefined) {
        entry.LineCount = params.lineCount;
    }
    if (params.connectorTime !== undefined) {
        entry.ConnectorTime = params.connectorTime;
    }
    if (params.latency !== undefined) {
        entry.ConnectorLatency = params.latency;
    }

    if (params.error) {
        logger.error(JSON.stringify(entry));
    } else {
        logger.info(JSON.stringify(entry));
    }
}

/**
 * Gets AvaTax configuration from Site Custom Preferences
 * @returns {Object} Configuration object
 */
function getConfig() {
    var currentSite = Site.getCurrent();

    return {
        companyCode: currentSite.getCustomPreferenceValue('AtCompanyCode') || '',
        enabled: currentSite.getCustomPreferenceValue('ATEnable') || false,
        saveTransactions: currentSite.getCustomPreferenceValue('AtDocumentCommitAllowed') || false,
        commitTransactions: currentSite.getCustomPreferenceValue('AtCommitTransaction') || false
    };
}

/**
 * Resolves the customer code to send to AvaTax based on ATCustomerCode preference.
 * Supports 4 strategies: customer_number, customer_email, custom_attribute, guest fallback.
 *
 * @param {dw.order.LineItemCtnr} basket - The basket or order
 * @returns {string} Customer code for AvaTax
 */
function getCustomerCode(basket) {
    var currentSite = Site.getCurrent();
    var customerCodePref = currentSite.getCustomPreferenceValue('ATCustomerCode') || 'customer_email';
    var customer = basket.getCustomer();

    if (customer && customer.profile) {
        var profile = customer.profile;

        if (customerCodePref === 'customer_number') {
            return profile.customerNo;
        }

        if (customerCodePref === 'customer_email') {
            return basket.getCustomerEmail() || profile.email;
        }

        if (customerCodePref === 'custom_attribute') {
            var customAttr = currentSite.getCustomPreferenceValue('ATCustomCustomerCode');
            if (customAttr) {
                try {
                    var customValue = profile[customAttr.toString().trim()];
                    if (customValue) {
                        return customValue;
                    }
                } catch (e) {
                    logger.warn('Cannot find custom attribute "' + customAttr + '" on customer profile. Falling back to customerNo. Error: ' + e.message);
                }
            }
            return profile.customerNo;
        }

        return profile.customerNo;
    }

    // Guest customer
    return basket.getCustomerEmail() || 'guest-cust-code';
}

/**
 * Builds a shipTo address object from a shipping or billing address.
 * @param {dw.order.OrderAddress} address - The address
 * @returns {Object} Address object for AvaTax line
 */
function buildShipToAddress(address) {
    return {
        line1: address.address1 || '',
        line2: address.address2 || '',
        city: address.city || '',
        region: address.stateCode || '',
        country: address.countryCode ? address.countryCode.value : '',
        postalCode: address.postalCode || ''
    };
}

/**
 * Builds the AvaTax CreateTransaction request payload.
 * Processes product line items, option line items, shipping line items,
 * and gift certificate line items.
 *
 * @param {dw.order.LineItemCtnr} basket - The basket or order
 * @returns {Object} Object with {model: transactionModel, lineUUIDMap: {lineNumber: UUID}}
 */
function buildTransactionModel(basket) {
    var TaxMgr = require('dw/order/TaxMgr');
    var currentSite = Site.getCurrent();
    var config = getConfig();

    var lines = [];
    var lineNumber = 0;
    var lineUUIDMap = {};

    var taxIncluded = (TaxMgr.taxationPolicy === TaxMgr.TAX_POLICY_GROSS);

    var customer = basket.getCustomer();
    var customerTaxId = (customer && customer.profile) ? customer.profile.taxID : null;
    var isSellerImporterOfRecord = (customer && customer.profile) ? customer.profile.custom.ATisSellerImporterOfRecord : false;

    var shipFrom = {
        locationCode: currentSite.getCustomPreferenceValue('AtShipFromLocationCode') || '',
        line1: currentSite.getCustomPreferenceValue('AtShipFromLine1') || '',
        line2: currentSite.getCustomPreferenceValue('AtShipFromLine2') || '',
        city: currentSite.getCustomPreferenceValue('AtShipFromCity') || '',
        region: currentSite.getCustomPreferenceValue('AtShipFromStateCode') || '',
        country: currentSite.getCustomPreferenceValue('AtShipFromCountryCode') || '',
        postalCode: currentSite.getCustomPreferenceValue('AtShipFromZipCode') || '',
        latitude: currentSite.getCustomPreferenceValue('AtShipFromLatitude') || '',
        longitude: currentSite.getCustomPreferenceValue('AtShipFromLongitude') || ''
    };

    var defaultProductTaxCode = currentSite.getCustomPreferenceValue('AtDefaultProductTaxCode') || '';
    var defaultShippingTaxCode = currentSite.getCustomPreferenceValue('ATDefaultShippingMethodTaxCode') || '';

    // --- Product line items ---
    var productLineItems = basket.getProductLineItems();
    var pliIterator = productLineItems.iterator();
    while (pliIterator.hasNext()) {
        var pli = pliIterator.next();
        var shipment = pli.getShipment();

        if (!shipment || !shipment.getShippingAddress()) {
            continue;
        }

        var shipTo = buildShipToAddress(shipment.getShippingAddress());

        var product = pli.getProduct();
        var pliItemCode = (product && product.UPC) ? ('UPC:' + product.UPC) : pli.productName;
        var pliDescription = (product && product.shortDescription) ? product.shortDescription.source.toString() : '';

        lineNumber++;
        lineUUIDMap[lineNumber] = { uuid: pli.UUID, shipmentId: shipment.ID, itemId: pli.productID };
        lines.push({
            number: lineNumber,
            quantity: pli.quantityValue,
            amount: pli.proratedPrice.value,
            taxCode: (product && product.taxClassID) ? product.taxClassID : defaultProductTaxCode,
            itemCode: pliItemCode.substring(0, 50),
            description: pliDescription.substring(0, 255),
            taxIncluded: taxIncluded,
            businessIdentificationNo: customerTaxId,
            addresses: {
                shipFrom: shipFrom,
                shipTo: shipTo
            }
        });

        // Option line items for this product
        var oliIterator = pli.optionProductLineItems.iterator();
        while (oliIterator.hasNext()) {
            var oli = oliIterator.next();
            lineNumber++;
            lineUUIDMap[lineNumber] = { uuid: oli.UUID, shipmentId: shipment.ID, itemId: oli.optionID };
            lines.push({
                number: lineNumber,
                quantity: oli.quantityValue,
                amount: oli.proratedPrice.value,
                taxCode: oli.taxClassID || defaultProductTaxCode,
                itemCode: (oli.productName || oli.optionID).substring(0, 50),
                description: oli.productName || '',
                taxIncluded: taxIncluded,
                businessIdentificationNo: customerTaxId,
                addresses: {
                    shipFrom: shipFrom,
                    shipTo: shipTo
                }
            });
        }

        // Product-level shipping line item (e.g., surcharge for oversized items)
        if (pli.shippingLineItem) {
            var psli = pli.shippingLineItem;
            lineNumber++;
            lineUUIDMap[lineNumber] = { uuid: psli.UUID, shipmentId: shipment.ID, itemId: psli.ID };
            lines.push({
                number: lineNumber,
                quantity: 1,
                amount: psli.adjustedPrice.value,
                taxCode: psli.taxClassID || defaultShippingTaxCode,
                itemCode: (psli.lineItemText || psli.ID).substring(0, 50),
                description: psli.lineItemText || 'Product Shipping',
                taxIncluded: taxIncluded,
                businessIdentificationNo: customerTaxId,
                addresses: {
                    shipFrom: shipFrom,
                    shipTo: shipTo
                }
            });
        }
    }

    // --- Shipping line items ---
    var shipmentsIterator = basket.getShipments().iterator();
    while (shipmentsIterator.hasNext()) {
        var shipment = shipmentsIterator.next();
        var shippingAddress = shipment.getShippingAddress();

        if (!shippingAddress) {
            continue;
        }

        var shipTo = buildShipToAddress(shippingAddress);

        var shippingLineItems = shipment.getShippingLineItems().iterator();
        while (shippingLineItems.hasNext()) {
            var sli = shippingLineItems.next();
            var shippingAmount = sli.adjustedPrice ? sli.adjustedPrice.value : 0;

            if (shippingAmount <= 0) {
                continue;
            }

            lineNumber++;
            lineUUIDMap[lineNumber] = { uuid: sli.UUID, shipmentId: shipment.ID, itemId: sli.ID };
            lines.push({
                number: lineNumber,
                quantity: 1,
                amount: shippingAmount,
                taxCode: sli.taxClassID || defaultShippingTaxCode,
                itemCode: sli.ID.substring(0, 50),
                description: sli.lineItemText || 'Shipping',
                taxIncluded: taxIncluded,
                businessIdentificationNo: customerTaxId,
                addresses: {
                    shipFrom: shipFrom,
                    shipTo: shipTo
                }
            });
        }
    }

    // --- Gift certificate line items ---
    var giftCertIterator = basket.getGiftCertificateLineItems().iterator();
    while (giftCertIterator.hasNext()) {
        var giftCert = giftCertIterator.next();
        var gcShipment = giftCert.shipment;
        var gcAddress = (gcShipment && gcShipment.getShippingAddress()) ? gcShipment.getShippingAddress() : basket.getBillingAddress();

        if (!gcAddress) {
            continue;
        }

        var shipTo = buildShipToAddress(gcAddress);

        lineNumber++;
        lineUUIDMap[lineNumber] = { uuid: giftCert.UUID, shipmentId: gcShipment ? gcShipment.ID : '', itemId: giftCert.giftCertificateID };
        lines.push({
            number: lineNumber,
            quantity: 1,
            amount: giftCert.getPriceValue(),
            taxCode: 'PG050000',
            itemCode: (giftCert.lineItemText || 'GiftCertificate').substring(0, 50),
            description: giftCert.lineItemText || 'Gift Certificate',
            taxIncluded: taxIncluded,
            businessIdentificationNo: customerTaxId,
            addresses: {
                shipFrom: shipFrom,
                shipTo: shipTo
            }
        });
    }

    if (lines.length === 0) {
        logger.warn('No taxable line items found for basket ' + basket.getUUID());
    }

    var transactionModel = {
        code: basket.getUUID(),
        type: 'SalesOrder',
        companyCode: config.companyCode,
        date: new Date().toISOString().split('T')[0],
        customerCode: getCustomerCode(basket),
        currencyCode: basket.getCurrencyCode(),
        businessIdentificationNo: customerTaxId,
        isSellerImporterOfRecord: isSellerImporterOfRecord,
        debugLevel: 'Normal',
        serviceMode: 'Automatic',
        lines: lines,
        commit: false
    };

    return {
        model: transactionModel,
        lineUUIDMap: lineUUIDMap
    };
}

/**
 * Calls AvaTax CreateTransaction API with request deduplication.
 * Hashes the transaction model and compares against the session to skip
 * redundant API calls when the basket hasn't changed.
 *
 * @param {Object} transactionModel - The transaction request payload
 * @returns {Object} Response object with {success: boolean, data: Object, error: String, deduplicated: boolean}
 */
function callAvaTaxAPI(transactionModel) {
    var murmurhash = require('~/cartridge/scripts/helpers/murmurhash');
    var enterTime = Date.now();
    var modelJson = JSON.stringify(transactionModel);
    var hash = murmurhash.hashBytes(modelJson, modelJson.length, 523);

    // Use == (loose equality) because session.custom may store the number as a string
    if (session.custom.avataxtransactionmodel && session.custom.avataxtransactionmodel == hash) {
        return { success: true, data: null, deduplicated: true };
    }

    var response = avataxService.call('POST', '/api/v2/transactions/create', transactionModel);

    var completionTime = Date.now();
    var connectorTime = (completionTime - enterTime) - (response.latency || 0);

    if (response.success) {
        session.custom.avataxtransactionmodel = hash;

        logStructured({
            operation: 'CreateTransaction',
            docCode: transactionModel.code || '',
            logType: 'Performance',
            logLevel: 'Informational',
            lineCount: transactionModel.lines ? transactionModel.lines.length : 0,
            connectorTime: connectorTime,
            latency: response.latency || 0,
            message: 'CreateTransaction succeeded. Lines: ' + (transactionModel.lines ? transactionModel.lines.length : 0) +
                ', Latency: ' + (response.latency || 0) + 'ms, ConnectorTime: ' + connectorTime + 'ms'
        });
    } else {
        logStructured({
            operation: 'CreateTransaction',
            docCode: transactionModel.code || '',
            logType: 'Debug',
            logLevel: 'Error',
            error: true,
            errorType: 'Data',
            lineCount: transactionModel.lines ? transactionModel.lines.length : 0,
            connectorTime: connectorTime,
            latency: response.latency || 0,
            message: 'CreateTransaction failed: ' + response.error
        });
    }

    return response;
}

/**
 * Commits a previously created transaction in AvaTax.
 *
 * @param {string} transactionCode - The transaction code (order number)
 * @returns {Object} Response object with {success: boolean, data: Object, error: String}
 */
function commitTransaction(transactionCode) {
    var config = getConfig();

    if (!config.saveTransactions) {
        logger.warn('Document commit not allowed — AtDocumentCommitAllowed is disabled');
        return {
            success: false,
            error: "Document commit not allowed for this site. Enable 'AtDocumentCommitAllowed' in Site Preferences."
        };
    }

    if (!config.companyCode) {
        logger.error('AtCompanyCode not configured in site preferences');
        return { success: false, error: 'AtCompanyCode not configured in Site Preferences.' };
    }

    var endpoint = '/api/v2/companies/' + encodeURIComponent(config.companyCode) +
        '/transactions/' + encodeURIComponent(transactionCode) + '/commit';

    var response = avataxService.call('POST', endpoint, { commit: true });

    logStructured({
        operation: 'CommitTransaction',
        docCode: transactionCode,
        logType: response.success ? 'Performance' : 'Debug',
        logLevel: response.success ? 'Informational' : 'Error',
        error: !response.success,
        errorType: response.success ? undefined : 'Data',
        latency: response.latency || 0,
        message: response.success
            ? 'CommitTransaction succeeded for ' + transactionCode
            : 'CommitTransaction failed: ' + response.error
    });

    return response;
}

/**
 * Voids a previously saved transaction in AvaTax.
 *
 * @param {string} transactionCode - The transaction code (order number)
 * @returns {Object} Response object with {success: boolean, data: Object, error: String}
 */
function voidTransaction(transactionCode) {
    var config = getConfig();

    if (!config.saveTransactions) {
        logger.warn('Document void not allowed — AtDocumentCommitAllowed is disabled');
        return {
            success: false,
            error: "Document void not allowed for this site. Enable 'AtDocumentCommitAllowed' in Site Preferences."
        };
    }

    if (!config.companyCode) {
        logger.error('AtCompanyCode not configured in site preferences');
        return { success: false, error: 'AtCompanyCode not configured in Site Preferences.' };
    }

    var endpoint = '/api/v2/companies/' + encodeURIComponent(config.companyCode) +
        '/transactions/' + encodeURIComponent(transactionCode) + '/void';

    var response = avataxService.call('POST', endpoint, { code: 'DocVoided' });

    logStructured({
        operation: 'VoidTransaction',
        docCode: transactionCode,
        logType: response.success ? 'Performance' : 'Debug',
        logLevel: response.success ? 'Informational' : 'Error',
        error: !response.success,
        errorType: response.success ? undefined : 'Data',
        latency: response.latency || 0,
        message: response.success
            ? 'VoidTransaction succeeded for ' + transactionCode
            : 'VoidTransaction failed: ' + response.error
    });

    return response;
}

/**
 * Finds a line item in the basket by its UUID.
 * Checks all line items including nested shipping line items on product line items.
 *
 * @param {dw.order.LineItemCtnr} basket - The basket
 * @param {string} uuid - The UUID to find
 * @returns {dw.order.LineItem|null} The matching line item or null
 */
function getLineItemByUUID(basket, uuid) {
    var allLineItems = basket.getAllLineItems().iterator();
    while (allLineItems.hasNext()) {
        var li = allLineItems.next();
        if (li.UUID === uuid) {
            return li;
        }
        if ('shippingLineItem' in li && li.shippingLineItem && li.shippingLineItem.UUID === uuid) {
            return li.shippingLineItem;
        }
    }
    return null;
}

/**
 * Applies AvaTax response to basket line items using UUID-based matching.
 *
 * @param {dw.order.LineItemCtnr} basket - The basket
 * @param {Object} avaTaxResponse - Response from AvaTax API
 * @param {Object} lineUUIDMap - Map of line numbers to line item UUIDs
 */
function applyTaxesToBasket(basket, avaTaxResponse, lineUUIDMap) {
    if (!avaTaxResponse || !avaTaxResponse.lines) {
        logger.warn('No tax lines in AvaTax response');
        return;
    }

    var Money = require('dw/value/Money');
    var ProductLineItem = require('dw/order/ProductLineItem');
    var ProductShippingLineItem = require('dw/order/ProductShippingLineItem');
    var ShippingLineItem = require('dw/order/ShippingLineItem');
    var currencyCode = basket.getCurrencyCode();

    var responseLines = avaTaxResponse.lines;
    for (var i = 0; i < responseLines.length; i++) {
        var resLine = responseLines[i];
        var lineInfo = lineUUIDMap[resLine.lineNumber];

        if (!lineInfo) {
            logger.warn('No UUID mapping for AvaTax line number ' + resLine.lineNumber);
            continue;
        }

        var lineItem = getLineItemByUUID(basket, lineInfo.uuid);
        if (!lineItem) {
            logger.warn('Line item not found for UUID ' + lineInfo.uuid + ' (line ' + resLine.lineNumber + ')');
            continue;
        }

        var taxRate = 0;
        if (resLine.taxableAmount > 0) {
            taxRate = resLine.tax / resLine.taxableAmount;
        }

        var taxMoney = new Money(resLine.tax, currencyCode);
        lineItem.setTaxRate(taxRate);
        lineItem.updateTax(taxRate);
        lineItem.tax = taxMoney;

        // Zero out tax on price adjustments for this line item
        if (lineItem instanceof ProductLineItem || lineItem instanceof ProductShippingLineItem) {
            var paIterator = lineItem.priceAdjustments.iterator();
            while (paIterator.hasNext()) {
                paIterator.next().updateTax(0);
            }
        } else if (lineItem instanceof ShippingLineItem) {
            var spaIterator = lineItem.shippingPriceAdjustments.iterator();
            while (spaIterator.hasNext()) {
                spaIterator.next().updateTax(0);
            }
        }
    }

    // Zero out basket-level price adjustments
    var basketPAIterator = basket.priceAdjustments.iterator();
    while (basketPAIterator.hasNext()) {
        basketPAIterator.next().updateTax(0);
    }
    var basketSPAIterator = basket.shippingPriceAdjustments.iterator();
    while (basketSPAIterator.hasNext()) {
        basketSPAIterator.next().updateTax(0);
    }

    // Store per-line jurisdiction tax breakdown in ATTaxDetail
    storeTaxDetails(basket, avaTaxResponse, lineUUIDMap);

    // Extract and store VAT invoice messages (EU)
    storeInvoiceMessages(basket, avaTaxResponse);

    basket.updateTotals();
}

/**
 * Builds a per-line jurisdiction tax breakdown and stores it in basket.custom.ATTaxDetail.
 *
 * @param {dw.order.LineItemCtnr} basket - The basket
 * @param {Object} avaTaxResponse - Response from AvaTax API
 * @param {Object} lineUUIDMap - Map of line numbers to line item UUIDs
 */
function storeTaxDetails(basket, avaTaxResponse, lineUUIDMap) {
    var taxDetailsJSON = [];

    if (!avaTaxResponse.lines) {
        return;
    }

    var lines = avaTaxResponse.lines;
    for (var i = 0; i < lines.length; i++) {
        var resItem = lines[i];
        var jsonObj = {};

        if (resItem.details) {
            var taxes = [];
            for (var j = 0; j < resItem.details.length; j++) {
                var detail = resItem.details[j];
                taxes.push({
                    jurisdictiontype: detail.jurisdictionType,
                    jurisdiction: detail.jurisName,
                    exempt: detail.exemptAmount,
                    nontaxable: detail.nonTaxableAmount,
                    taxable: detail.taxableAmount,
                    rate: detail.rate,
                    tax: detail.tax
                });
            }
            var lineInfo = lineUUIDMap[resItem.lineNumber];

            jsonObj.lineitemid = lineInfo ? (lineInfo.itemId || resItem.lineNumber) : resItem.lineNumber;
            jsonObj.shipmentid = lineInfo ? lineInfo.shipmentId : '';
            jsonObj.taxes = taxes;
        }

        taxDetailsJSON.push(jsonObj);
    }

    try {
        basket.custom.ATTaxDetail = JSON.stringify(taxDetailsJSON);
    } catch (e) {
        logger.warn('Could not store ATTaxDetail: ' + e.message);
    }
}

/**
 * Extracts VAT invoice messages from the AvaTax response and stores
 * them in basket.custom.ATInvoiceMessage.
 *
 * @param {dw.order.LineItemCtnr} basket - The basket
 * @param {Object} avaTaxResponse - Response from AvaTax API
 */
function storeInvoiceMessages(basket, avaTaxResponse) {
    if (!avaTaxResponse.messages || !avaTaxResponse.messages.length) {
        return;
    }

    var msgDetails = '';
    var messages = avaTaxResponse.messages;
    for (var i = 0; i < messages.length; i++) {
        if (messages[i].summary && messages[i].summary.toString().toLowerCase().indexOf('invoice  messages') !== -1) {
            msgDetails = messages[i].details;
            break;
        }
    }

    try {
        basket.custom.ATInvoiceMessage = msgDetails;
        session.custom.ATInvoiceMessage = msgDetails;
    } catch (e) {
        logger.warn('Could not store ATInvoiceMessage: ' + e.message);
    }
}

/**
 * Tests the connection to the AvaTax API by calling the ping endpoint.
 *
 * @returns {Object} Response object with {success: boolean, authenticated: boolean, error: String}
 */
function testConnection() {
    var response = avataxService.call('GET', '/api/v2/utilities/ping', null);

    if (!response.success) {
        logStructured({
            operation: 'TestConnection',
            logType: 'Debug',
            logLevel: 'Error',
            error: true,
            errorType: 'Configuration',
            message: 'TestConnection failed: ' + response.error
        });
        return { success: false, error: response.error };
    }

    var authenticated = response.data && response.data.authenticated;

    logStructured({
        operation: 'TestConnection',
        logType: 'Performance',
        logLevel: 'Informational',
        latency: response.latency || 0,
        message: 'TestConnection succeeded. Authenticated: ' + authenticated
    });

    return {
        success: true,
        authenticated: authenticated,
        data: response.data
    };
}

module.exports = {
    buildTransactionModel: buildTransactionModel,
    callAvaTaxAPI: callAvaTaxAPI,
    applyTaxesToBasket: applyTaxesToBasket,
    commitTransaction: commitTransaction,
    voidTransaction: voidTransaction,
    testConnection: testConnection,
    getConfig: getConfig
};