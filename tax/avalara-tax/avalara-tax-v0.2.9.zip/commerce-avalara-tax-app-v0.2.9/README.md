# Avalara Tax Integration for Commerce Cloud

This cartridge integrates Avalara AvaTax with Salesforce Commerce Cloud to provide real-time tax calculation, transaction management, and tax reporting capabilities.

## Package manifest

This package includes a root-level **`commerce-app.json`** manifest: app identity, domain, version, capabilities, cartridge and Storefront Next extension paths, and other extensible metadata. Post-install checklist tasks remain in **`app-configuration/tasksList.json`**. Tools and registries can read `commerce-app.json` for package-level metadata without relying on an external registry manifest alone.

## Overview

The Avalara Tax App provides:
- Real-time tax calculation for orders
- Tax breakdown details per jurisdiction (state, county, city, etc.)
- Transaction commitment and void support via AvaTax API
- Request deduplication to avoid redundant API calls
- Storefront Next tax breakdown component

## Cartridge Structure

### Site Cartridges
- **int_avatax**: Core AvaTax integration cartridge containing hook scripts, service definitions, and helpers. Uses a hook-based architecture so it works regardless of storefront framework.

### Business Manager Cartridges
- **bm_avatax**: Placeholder for future Business Manager extensions (currently empty)

### Storefront Next
- **storefront-next/src/extensions/avalara-tax**: Tax breakdown component that splits the tax total into state and federal line items in the order summary

## Installation

### Prerequisites
- Avalara AvaTax account with API credentials
- Company Code configured in AvaTax

### Steps

1. **Import Metadata and Services**
   ```
   impex/install/meta/system-objecttype-extensions.xml
   impex/install/services.xml
   impex/install/sites/SITEID/preferences.xml
   ```

2. **Configure AvaTax Service Credentials**
   - Navigate to Administration > Operations > Services
   - Update `credentials.avatax.rest` with your AvaTax credentials:
     - URL: Use sandbox URL for testing or production URL for live transactions
     - User ID: Your AvaTax account ID
     - Password: Your AvaTax license key

3. **Configure Site Preferences**
   - Navigate to Merchant Tools > Site Preferences > Custom Preferences > AvaTax
   - Configure the following:
     - **Enable Avatax**: Set to Yes to enable tax calculation
     - **Company Code**: Your AvaTax company code
     - **Ship From Address**: Configure your origin address
     - **Document Commit Settings**: Configure transaction commitment behavior
     - **Customer Code Strategy**: Choose how to identify customers sent to AvaTax

4. **Upload Cartridges**
   - Upload cartridges to your instance
   - Add to cartridge path in site settings: `int_avatax:[other_cartridges]`

## Configuration

### Site Preferences (AvaTax Group)

| Preference | Description | Default |
|------------|-------------|---------|
| **ATEnable** | Enable/disable AvaTax integration | true |
| **AtDocumentCommitAllowed** | Allow commit/void API calls to AvaTax | true |
| **AtCommitTransaction** | Auto-commit transactions on successful payment | false |
| **AtCompanyCode** | Your AvaTax company code | (required) |
| **ATCustomerCode** | Customer identifier strategy (`customer_number`, `customer_email`, `custom_attribute`) | customer_number |
| **ATCustomCustomerCode** | Custom profile attribute name (used when ATCustomerCode is `custom_attribute`) | (optional) |
| **AtDefaultProductTaxCode** | Default tax code for products without a tax class | (optional) |
| **ATDefaultShippingMethodTaxCode** | Tax code for shipping line items | FR |
| **AtShipFromLocationCode** | AvaTax location code for origin | (optional) |
| **AtShipFromLine1** | Origin street address line 1 | (required) |
| **AtShipFromLine2** | Origin street address line 2 | (optional) |
| **AtShipFromCity** | Origin city | (required) |
| **AtShipFromStateCode** | Origin state/region code | (required) |
| **AtShipFromCountryCode** | Origin country code | (required) |
| **AtShipFromZipCode** | Origin postal code | (required) |
| **AtShipFromLatitude** | Origin latitude override | (optional) |
| **AtShipFromLongitude** | Origin longitude override | (optional) |

### Service Configuration

The integration uses the following service:
- **Service ID**: `avatax.rest.all`
- **Credential ID**: `credentials.avatax.rest`
- **Profile ID**: `profile.avatax.rest`

## Features

### Tax Calculation
- Real-time tax calculation during checkout via the `calculate` hook
- Product, option, shipping, and gift certificate line item support
- Per-jurisdiction tax breakdown stored in `basket.custom.ATTaxDetail`
- VAT invoice message extraction stored in `basket.custom.ATInvoiceMessage`
- Request deduplication using MurmurHash to skip redundant API calls when the basket hasn't changed

### Transaction Management
- Commit transactions on order placement via the `commit` hook
- Void/cancel transactions on order cancellation via the `cancel` hook
- Controlled by `AtDocumentCommitAllowed` and `AtCommitTransaction` preferences

### Custom Attributes

The cartridge writes the following custom attributes at runtime:
- **basket.custom.ATTaxDetail**: Per-line jurisdiction tax breakdown (JSON)
- **basket.custom.ATInvoiceMessage**: VAT invoice messages extracted from the AvaTax response

## Testing

Unit tests are included under `cartridges/site_cartridges/int_avatax/test/`:
- `unit/hooks/calculate.test.js` — tax calculation hook tests
- `unit/hooks/commit.test.js` — transaction commit hook tests
- `unit/hooks/cancel.test.js` — transaction void hook tests
- `unit/helpers/avataxHelper.test.js` — helper function tests (transaction model building, tax application, deduplication, etc.)

## Uninstallation

To uninstall the integration:
1. Remove `int_avatax` from cartridge paths
2. Import uninstall metadata: `impex/uninstall/`
3. Disable the AvaTax service

## Support

For AvaTax API documentation, visit: https://developer.avalara.com/

## Version History

### v0.2.8
- Removed hardcoded sandbox credentials and test defaults
- Moved API authentication to SFCC service framework (`avatax.rest.all`)
- Added configurable customer code strategies (`customer_number`, `customer_email`, `custom_attribute`)
- Added transaction commit and void support with `AtDocumentCommitAllowed` / `AtCommitTransaction` preferences
- Added request deduplication via MurmurHash
- Added structured logging matching Avalara connector standard
- Added unit tests for hooks and helpers
- Added Storefront Next tax breakdown component
