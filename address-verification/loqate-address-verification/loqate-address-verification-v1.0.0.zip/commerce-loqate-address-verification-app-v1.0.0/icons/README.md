# App Icon

The Loqate icon has been downloaded: `loqate-icon-original.jpeg`

## Next Steps

Before packaging:
1. Convert the JPEG to PNG format (recommended for better transparency support)
2. Resize to 512x512 pixels (optimal size for app registry)
3. Rename to `loqate.png` for use in manifest

## Conversion Command (using ImageMagick or similar)

```bash
# Using ImageMagick (if installed)
convert loqate-icon-original.jpeg -resize 512x512 loqate.png

# Using sips (macOS built-in)
sips -s format png loqate-icon-original.jpeg --out loqate.png
sips -Z 512 loqate.png
```

Once converted, the `iconName` in the root manifest should reference: `"iconName": "loqate.png"`
