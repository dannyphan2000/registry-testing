# Loqate Address Verification

Address Verification Application with GBG Loqate

## Overview

This app integrates GBG Loqate's Address Verify service to provide real-time address validation and autocomplete functionality during checkout. It helps ensure accurate shipping addresses, reduces delivery failures, and improves customer experience.

## Features

- Real-time address verification during checkout
- Address autocomplete with intelligent suggestions
- Global address coverage with local formatting
- Reduces shipping errors and return to sender rates
- Seamless integration with checkout shipping address form

## Prerequisites

- Salesforce Commerce Cloud B2C Commerce instance
- GBG Loqate account with API key
- Storefront Next environment

## Installation

1. Download the app from the Commerce App Registry
2. Import the app using Business Manager
3. Configure the API credentials in your environment variables

## Configuration

### API Credentials

Configure the following environment variables for your Loqate integration:

- **API Key:** `PUBLIC__app__extension__loqateAddressVerification__apiKey`
- **Enabled:** `PUBLIC__app__extension__loqateAddressVerification__enabled` (default: true)

You can set these in your `.env` file or Business Manager environment configuration.

### Developer Resources

- **Implementation Guide:** https://docs.loqate.com/our-services/address-verify/implementation-guide
- **API Documentation:** https://www.loqate.com/resources/support/apis/

## Post-Installation Checklist

- [ ] Configure API key in environment variables
- [ ] Test address verification on checkout page
- [ ] Verify address autocomplete dropdown appears
- [ ] Test with various international addresses
- [ ] Monitor API usage and rate limits

## Support

For questions or issues:
- Documentation: https://www.loqate.com/resources/support/
- Support: https://www.loqate.com/

## License

Proprietary - GBG Loqate

## Changelog

### v1.0.0
- Initial release
- Real-time address verification
- Address autocomplete integration
- Global address coverage
