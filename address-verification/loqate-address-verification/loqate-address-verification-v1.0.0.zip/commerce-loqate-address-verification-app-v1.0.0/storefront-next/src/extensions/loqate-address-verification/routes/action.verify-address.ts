/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/** @sfdc-extension-file SFDC_EXT_LOQATE_ADDRESS_VERIFICATION */

import { data, type ActionFunction } from 'react-router';

/**
 * Environment variables:
 * - LOQATE_API_KEY (required): Loqate API key for address verification
 */

const LOQATE_API_ENDPOINT = 'https://api.addressy.com/Cleansing/International/Batch/v1.20/json6.ws';

/**
 * Server action to verify addresses using Loqate API.
 *
 * Keeps the API key secure on the server side and proxies requests to Loqate.
 *
 * Form data:
 * - `address`: JSON string containing address fields
 *   - address1: string (required)
 *   - address2?: string
 *   - city: string (required)
 *   - stateCode: string (required)
 *   - postalCode: string (required)
 *   - countryCode: string (default: 'US')
 *
 * Returns:
 * - success: boolean
 * - data?: Loqate API response (array of results)
 * - error?: string (error message)
 */
export const action: ActionFunction = async ({ request }) => {
    const apiKey = process.env.LOQATE_API_KEY;

    if (!apiKey) {
        return data(
            {
                success: false,
                error: 'Address verification service not configured',
            },
            { status: 500 }
        );
    }

    try {
        const formData = await request.formData();
        const addressRaw = formData.get('address') as string;

        if (!addressRaw) {
            return data(
                {
                    success: false,
                    error: 'Address data is required',
                },
                { status: 400 }
            );
        }

        let address: {
            address1?: string;
            address2?: string;
            city?: string;
            stateCode?: string;
            postalCode?: string;
            countryCode?: string;
        };

        try {
            address = JSON.parse(addressRaw);
        } catch {
            return data(
                {
                    success: false,
                    error: 'Invalid address data format',
                },
                { status: 400 }
            );
        }

        const response = await fetch(LOQATE_API_ENDPOINT, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                Key: apiKey,
                Addresses: [
                    {
                        Address1: address.address1 || '',
                        Address2: address.address2 || '',
                        Locality: address.city || '',
                        AdministrativeArea: address.stateCode || '',
                        PostalCode: address.postalCode || '',
                        Country: address.countryCode || 'US',
                    },
                ],
                Geocode: true,
            }),
        });

        if (!response.ok) {
            return data(
                {
                    success: false,
                    error: `Address verification failed: ${response.status}`,
                },
                { status: response.status }
            );
        }

        const result = await response.json();

        return data({
            success: true,
            data: result,
        });
    } catch (error) {
        return data(
            {
                success: false,
                error: error instanceof Error ? error.message : 'Verification failed',
            },
            { status: 500 }
        );
    }
};
