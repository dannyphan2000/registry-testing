/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import AddressVerification from '../components/AddressVerification';
import type { UseLoqateVerificationResult } from '../hooks/useLoqateVerification';

const mockShippingAddress = {
    firstName: 'John',
    lastName: 'Doe',
    address1: '123 Main St',
    address2: '',
    city: 'New York',
    stateCode: 'NY',
    postalCode: '10001',
    countryCode: 'US',
    phone: '555-1234',
};

const mockFetcherSubmit = vi.fn();
let mockFetcherState = 'idle';

vi.mock('react-i18next', () => ({
    useTranslation: () => ({ t: (key: string) => key }),
}));

vi.mock('react-router', () => ({
    useFetcher: () => ({
        state: mockFetcherState,
        submit: mockFetcherSubmit,
    }),
}));

vi.mock('@/providers/basket', () => ({
    useBasket: () => ({
        shipments: [{ shippingAddress: mockShippingAddress }],
    }),
}));

vi.mock('@/components/ui/button', () => ({
    Button: ({ children, ...props }: React.ComponentProps<'button'>) => <button {...props}>{children}</button>,
}));

vi.mock('@/components/ui/alert', () => ({
    Alert: ({ children }: { children: React.ReactNode }) => <div data-testid="alert">{children}</div>,
    AlertTitle: ({ children }: { children: React.ReactNode }) => <div data-testid="alert-title">{children}</div>,
    AlertDescription: ({ children }: { children: React.ReactNode }) => (
        <div data-testid="alert-description">{children}</div>
    ),
}));

vi.mock('@/components/ui/badge', () => ({
    Badge: ({ children }: { children: React.ReactNode }) => <span data-testid="badge">{children}</span>,
}));

vi.mock('lucide-react', () => ({
    Loader2: () => <span data-testid="loader-icon" />,
    MapPin: () => <span data-testid="map-pin-icon" />,
    CheckCircle2: () => <span data-testid="check-icon" />,
    AlertTriangle: () => <span data-testid="warning-icon" />,
    XCircle: () => <span data-testid="error-icon" />,
}));

const defaultHookResult: UseLoqateVerificationResult = {
    status: 'idle',
    suggestions: [],
    verifiedAddress: null,
    error: null,
    verifyAddress: vi.fn(),
    selectAddress: vi.fn(),
    reset: vi.fn(),
};

let hookOverrides: Partial<UseLoqateVerificationResult> = {};

vi.mock('../hooks/useLoqateVerification', () => ({
    useLoqateVerification: () => ({ ...defaultHookResult, ...hookOverrides }),
}));

const mockUseLoqateContext = vi.fn().mockReturnValue({
    config: { apiKey: 'test-key', enabled: true, cacheTTL: 900000 },
    verifiedAddresses: new Map(),
    cacheVerifiedAddress: vi.fn(),
    getVerifiedAddress: vi.fn(),
    clearCache: vi.fn(),
});

vi.mock('../providers/LoqateProvider', () => ({
    useLoqateContext: (...args: unknown[]) => mockUseLoqateContext(...args),
}));

vi.mock('./VerificationStatus', () => ({
    default: () => <div data-testid="verification-status" />,
}));

vi.mock('./AddressSuggestions', () => ({
    default: () => <div data-testid="address-suggestions" />,
}));

describe('AddressVerification', () => {
    beforeEach(() => {
        vi.clearAllMocks();
        hookOverrides = {};
        mockFetcherState = 'idle';
    });

    it('renders the verify button when status is idle', () => {
        render(<AddressVerification />);
        expect(screen.getByText('loqateAddressVerification.button.verify')).toBeInTheDocument();
    });

    it('verify button is enabled when basket has a valid address', () => {
        render(<AddressVerification />);
        const button = screen.getByText('loqateAddressVerification.button.verify');
        expect(button).not.toBeDisabled();
    });

    it('calls verifyAddress with basket shipping address on click', async () => {
        const mockVerify = vi.fn();
        hookOverrides = { verifyAddress: mockVerify };

        render(<AddressVerification />);
        fireEvent.click(screen.getByText('loqateAddressVerification.button.verify'));

        await waitFor(() => {
            expect(mockVerify).toHaveBeenCalledWith({
                address1: '123 Main St',
                address2: '',
                city: 'New York',
                stateCode: 'NY',
                postalCode: '10001',
                countryCode: 'US',
            });
        });
    });

    it('shows loading state while verifying', () => {
        hookOverrides = { status: 'verifying' };
        render(<AddressVerification />);
        expect(screen.getByText('loqateAddressVerification.message.verifying')).toBeInTheDocument();
        expect(screen.getByTestId('loader-icon')).toBeInTheDocument();
    });

    it('shows "Use Verified Address" button for medium confidence', () => {
        hookOverrides = {
            status: 'verified',
            verifiedAddress: {
                address1: '123 Main St',
                city: 'New York',
                stateCode: 'NY',
                postalCode: '10001-1234',
                countryCode: 'US',
                verificationStatus: 'verified',
                confidence: 'medium',
                timestamp: Date.now(),
                metadata: { residential: true, commercial: false, aqi: 'B', matchLevel: 33, matchScore: 85 },
            },
        };

        render(<AddressVerification />);
        expect(screen.getByText('loqateAddressVerification.button.applyAddress')).toBeInTheDocument();
    });

    it('shows no action buttons for none confidence (rejected)', () => {
        hookOverrides = {
            status: 'partiallyVerified',
            verifiedAddress: {
                address1: '123 Fake St',
                city: 'Nowhere',
                stateCode: 'XX',
                postalCode: '00000',
                countryCode: 'US',
                verificationStatus: 'partiallyVerified',
                confidence: 'none',
                timestamp: Date.now(),
                metadata: { residential: false, commercial: false, matchLevel: 0, matchScore: 0 },
            },
        };

        render(<AddressVerification />);
        expect(screen.queryByText('loqateAddressVerification.button.verify')).not.toBeInTheDocument();
        expect(screen.queryByText('loqateAddressVerification.button.applyAddress')).not.toBeInTheDocument();
    });

    it('does not render when config is disabled', () => {
        mockUseLoqateContext.mockReturnValue({
            config: { apiKey: '', enabled: false, cacheTTL: 900000 },
            verifiedAddresses: new Map(),
            cacheVerifiedAddress: vi.fn(),
            getVerifiedAddress: vi.fn(),
            clearCache: vi.fn(),
        });

        const { container } = render(<AddressVerification />);
        expect(container.innerHTML).toBe('');
    });
});
