/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
'use client';

import type { ReactElement } from 'react';
import { useTranslation } from 'react-i18next';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import type { AddressSuggestion } from '../hooks/useLoqateVerification';

export interface AddressSuggestionsProps {
    suggestions: AddressSuggestion[];
    onSelect: (suggestion: AddressSuggestion) => void;
    onCancel: () => void;
}

function AddressSuggestions({ suggestions, onSelect, onCancel }: AddressSuggestionsProps): ReactElement {
    const { t } = useTranslation('extLoqateAddressVerification');

    const formatAddress = (suggestion: AddressSuggestion): string => {
        return [suggestion.address1, suggestion.address2, suggestion.city, suggestion.stateCode, suggestion.postalCode]
            .filter(Boolean)
            .join(', ');
    };

    return (
        <div className="mb-2 rounded-lg border bg-card p-3">
            <p className="mb-1 text-sm font-medium">{t('loqateAddressVerification.status.ambiguous.title')}</p>
            <p className="mb-2 text-xs text-muted-foreground">
                {t('loqateAddressVerification.message.selectSuggestion')}
            </p>

            <ul className="space-y-1">
                {suggestions.map((suggestion) => (
                    <li key={`${suggestion.address1}-${suggestion.postalCode}`}>
                        <button
                            type="button"
                            onClick={() => onSelect(suggestion)}
                            className="flex w-full items-center justify-between rounded-md px-3 py-2 text-left text-sm hover:bg-accent">
                            <span>{formatAddress(suggestion)}</span>
                            <span className="ml-2 flex shrink-0 gap-1">
                                {suggestion.metadata.residential && (
                                    <Badge variant="secondary">
                                        {t('loqateAddressVerification.metadata.residential')}
                                    </Badge>
                                )}
                                {suggestion.metadata.commercial && (
                                    <Badge variant="secondary">
                                        {t('loqateAddressVerification.metadata.commercial')}
                                    </Badge>
                                )}
                            </span>
                        </button>
                    </li>
                ))}
            </ul>

            <div className="mt-2">
                <Button type="button" variant="ghost" size="sm" onClick={onCancel}>
                    {t('loqateAddressVerification.button.cancel')}
                </Button>
            </div>
        </div>
    );
}

export default AddressSuggestions;
