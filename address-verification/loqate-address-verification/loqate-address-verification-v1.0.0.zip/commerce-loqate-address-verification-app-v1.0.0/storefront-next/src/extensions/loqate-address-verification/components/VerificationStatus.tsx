/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
'use client';

import type { ReactElement } from 'react';
import { useTranslation } from 'react-i18next';
import { CheckCircle2, AlertTriangle, XCircle } from 'lucide-react';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import type { VerificationStatus as VerificationStatusType, VerifiedAddress } from '../hooks/useLoqateVerification';

interface AddressFields {
    address1?: string | null;
    address2?: string | null;
    city?: string | null;
    stateCode?: string | null;
    postalCode?: string | null;
}

export interface VerificationStatusProps {
    status: VerificationStatusType;
    verifiedAddress?: VerifiedAddress | null;
    originalAddress?: AddressFields | null;
    error?: string | null;
}

const statusConfig = {
    verified: { Icon: CheckCircle2, variant: 'default' as const, aqiBadge: 'success' as const },
    partiallyVerified: { Icon: AlertTriangle, variant: 'default' as const, aqiBadge: 'warning' as const },
    unverified: { Icon: XCircle, variant: 'destructive' as const, aqiBadge: 'destructive' as const },
    error: { Icon: XCircle, variant: 'destructive' as const, aqiBadge: 'destructive' as const },
};

function formatAddress(addr: AddressFields): string {
    const street = [addr.address1, addr.address2].filter(Boolean).join(', ');
    const locality = [addr.city, addr.stateCode, addr.postalCode].filter(Boolean).join(', ');
    return [street, locality].filter(Boolean).join('\n');
}

function addressesMatch(a: AddressFields, b: AddressFields): boolean {
    return (
        (a.address1 || '') === (b.address1 || '') &&
        (a.address2 || '') === (b.address2 || '') &&
        (a.city || '') === (b.city || '') &&
        (a.stateCode || '') === (b.stateCode || '') &&
        (a.postalCode || '') === (b.postalCode || '')
    );
}

function VerificationStatus({
    status,
    verifiedAddress,
    originalAddress,
    error,
}: VerificationStatusProps): ReactElement {
    const { t } = useTranslation('extLoqateAddressVerification');
    const config = statusConfig[status as keyof typeof statusConfig];

    if (!config) return <></>;

    const { Icon, variant } = config;
    const confidence = verifiedAddress?.confidence;
    const aqi = verifiedAddress?.metadata?.aqi;
    const matchScore = verifiedAddress?.metadata?.matchScore;
    const isVerified = status === 'verified' || status === 'partiallyVerified';
    const hasCorrections =
        isVerified && originalAddress && verifiedAddress && !addressesMatch(originalAddress, verifiedAddress);

    const titleKey = `loqateAddressVerification.status.${status}.title`;
    const fallbackDescKey = `loqateAddressVerification.status.${status}.description`;
    const descriptionKey =
        confidence === 'medium'
            ? 'loqateAddressVerification.confidence.medium'
            : confidence === 'low'
              ? 'loqateAddressVerification.confidence.low'
              : fallbackDescKey;

    return (
        <Alert variant={variant} className="mb-3">
            <Icon className="size-4" />
            <AlertTitle className="flex items-center gap-2">
                {t(titleKey as 'loqateAddressVerification.status.verified.title')}
                {aqi && (
                    <Badge variant={config.aqiBadge} className="text-[10px] leading-none">
                        {t(`loqateAddressVerification.aqi.${aqi}`)}
                    </Badge>
                )}
                {matchScore !== undefined && matchScore > 0 && (
                    <Badge variant="outline" className="text-[10px] leading-none">
                        {matchScore}%
                    </Badge>
                )}
            </AlertTitle>
            <AlertDescription>
                <p>{error || t(descriptionKey as 'loqateAddressVerification.status.verified.description')}</p>

                {hasCorrections && (
                    <div className="mt-2 grid grid-cols-2 gap-2 text-sm">
                        <div className="rounded-md bg-muted/50 px-3 py-2">
                            <p className="text-xs font-medium text-muted-foreground mb-1">
                                {t('loqateAddressVerification.comparison.original')}
                            </p>
                            {formatAddress(originalAddress)
                                .split('\n')
                                .map((line) => (
                                    <p key={line} className="text-muted-foreground line-through">
                                        {line}
                                    </p>
                                ))}
                        </div>
                        <div className="rounded-md bg-muted/50 px-3 py-2">
                            <p className="text-xs font-medium text-muted-foreground mb-1">
                                {t('loqateAddressVerification.comparison.corrected')}
                            </p>
                            {formatAddress(verifiedAddress)
                                .split('\n')
                                .map((line) => (
                                    <p key={line} className="font-medium text-foreground">
                                        {line}
                                    </p>
                                ))}
                        </div>
                    </div>
                )}

                {isVerified && !hasCorrections && verifiedAddress && (
                    <div className="mt-2 rounded-md bg-muted/50 px-3 py-2 text-sm">
                        <p className="text-xs font-medium text-muted-foreground mb-1">
                            {t('loqateAddressVerification.message.suggestedAddress')}
                        </p>
                        {formatAddress(verifiedAddress)
                            .split('\n')
                            .map((line) => (
                                <p key={line} className="font-medium text-foreground">
                                    {line}
                                </p>
                            ))}
                    </div>
                )}

                {verifiedAddress?.metadata && isVerified && (
                    <div className="mt-2 flex flex-wrap gap-1.5">
                        {verifiedAddress.metadata.residential && (
                            <Badge variant="secondary">{t('loqateAddressVerification.metadata.residential')}</Badge>
                        )}
                        {verifiedAddress.metadata.commercial && (
                            <Badge variant="secondary">{t('loqateAddressVerification.metadata.commercial')}</Badge>
                        )}
                    </div>
                )}
            </AlertDescription>
        </Alert>
    );
}

export default VerificationStatus;
